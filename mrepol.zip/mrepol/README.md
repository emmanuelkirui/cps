<img src="https://media2.giphy.com/media/2ikwIgNrmPZICNmRyX/200w.gif?cid=6c09b952zcomyf1rulliuonn48087xefmpnyc9nxkrp8uyor&ep=v1_gifs_search&rid=200w.gif&ct=g" align="right" width="200px"/>

# mrepol742.github.io
This is where i showcase my projects, landing pages, tools and other awesome things.
## Start
```bash
php -S localhost:8000
```

## Contribute
Code contributions are welcome! Please commit any pull requests against the master branch. Security audits and feedback are welcome. Please open an issue or email us privately if the report is sensitive in nature.
<br clear="left"/>
